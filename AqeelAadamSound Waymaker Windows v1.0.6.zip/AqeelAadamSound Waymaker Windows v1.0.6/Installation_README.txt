Waymaker - Aqeel Aadam Sound
Windows Installation Instructions

I would like to firstly offer an apology that an installer .exe does not yet exist for this product. As a fledgling developer, the costs of signing and certifying an installer application were prohibitively expensive. I did not want the poor user experience of grappling with an unsigned installer application that was blocked from running by default, and required you jump through hoops to get things working. Instead, I leave it in your hands to perform one copy-paste operation. Thank you for your understanding.

* Please copy the .vst3 file to the directory C:\Program Files\Common Files\VST3. If the VST3 folder does not yet exist, it should be safe to create it. This is a standard folder that most DAWs recognize and know to look for.

* Please copy the .aaxplugin file to the directory C:\Program Files\Common Files\Avid\Audio\Plug-Ins.

Alternatively, some DAWs (such as Ableton) allow you to define a custom VST3 folder for your DAW to source from. If you would prefer this route, place the enclosed .vst3 file in any directory of your choosing, and point your DAW to look for this custom VST3 folder.

At this point, you will need to restart your DAW, if it is currently open. Upon restart, please re-scan your plug-ins. Waymaker can be found under the manufacturer Aqeel Aadam Sound. If the plug-in is not found, please try restarting your machine and trying again.

Please note that Waymaker will require an internet connection for initial license validation. Afterwards, this will not be necessary.

Please find an enclosed .pdf manual for Waymaker as well.

If there are any issues, please do not hesitate to contact me at aqeelaadammusic@gmail.com.
